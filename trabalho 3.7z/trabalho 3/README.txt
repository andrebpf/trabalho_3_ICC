Trabalho 3 de Introdu��o � ci�ncia da computa��o (SSC 0600) :

 Membros: Ot�vio Cury Pontes - 10716525 - P0;
	  Andr� Baconcelo Prado Furlanetti - 10748305 - P1;
	  Daniel Bernardes Pozzan - 10716608 - P2;
	  
	 O trabalho � constitu�do de um c�digo em linguagem C desenvolvido no Windows 
(Codeblocks) e possui as seguintes funcionalidades:

		Cria��o da matriz m por n.
			-Exclus�o da matriz;
			-Consulta dos valores de uma posi��o (i, j) da matriz;
			-Consulta da soma dos valores de cada linha da matriz;
			-Consulta da soma dos valores de cada coluna da matriz;
			-Atribui��o de um valor na posi��o (i, j) da matriz;
		
